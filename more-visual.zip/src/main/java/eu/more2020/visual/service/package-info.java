/**
 * Service layer beans.
 */
package eu.more2020.visual.service;
