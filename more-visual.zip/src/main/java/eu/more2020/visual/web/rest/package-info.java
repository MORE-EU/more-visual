/**
 * Spring MVC REST controllers.
 */
package eu.more2020.visual.web.rest;
