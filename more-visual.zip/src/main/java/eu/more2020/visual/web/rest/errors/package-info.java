/**
 * Specific errors used with Zalando's "problem-spring-web" library.
 * <p>
 * More information on https://github.com/zalando/problem-spring-web
 */
package eu.more2020.visual.web.rest.errors;
