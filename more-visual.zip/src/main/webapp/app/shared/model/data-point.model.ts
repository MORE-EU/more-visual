export interface IDataPoint {
  timestamp: string;
  values: number[];
  timeRange: number[];
}
