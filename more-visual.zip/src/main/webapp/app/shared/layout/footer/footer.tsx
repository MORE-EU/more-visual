import './footer.scss';

import React from 'react';

const Footer = props => (
  <div className="footer page-content">
  </div>
);

export default Footer;
